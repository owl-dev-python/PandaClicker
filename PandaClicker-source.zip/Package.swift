// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PandaClicker",
    platforms: [
        .macOS(.v13)
    ],
    products: [
        .executable(name: "PandaClicker", targets: ["PandaClicker"])
    ],
    targets: [
        .executableTarget(
            name: "PandaClicker",
            path: "Sources/PandaClicker"
        )
    ]
)
