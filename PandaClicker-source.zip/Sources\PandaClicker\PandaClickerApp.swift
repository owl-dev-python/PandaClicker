import SwiftUI
import AppKit
import ApplicationServices

enum ClickButton: String, CaseIterable, Identifiable {
    case left = "Left"
    case right = "Right"

    var id: String { rawValue }

    var cgButton: CGMouseButton {
        switch self {
        case .left:
            return .left
        case .right:
            return .right
        }
    }

    var downEvent: CGEventType {
        switch self {
        case .left:
            return .leftMouseDown
        case .right:
            return .rightMouseDown
        }
    }

    var upEvent: CGEventType {
        switch self {
        case .left:
            return .leftMouseUp
        case .right:
            return .rightMouseUp
        }
    }
}

final class ClickerEngine: ObservableObject {
    @Published var intervalMillis: Double = 100
    @Published var clicksPerBurst: Int = 1
    @Published var maxClicks: Int = 0
    @Published var button: ClickButton = .left
    @Published private(set) var isRunning = false
    @Published private(set) var totalClicks = 0
    @Published private(set) var hasAccessibility = AXIsProcessTrusted()

    private var timer: DispatchSourceTimer?
    private let clickQueue = DispatchQueue(label: "dev.owldev.pandaclicker.clicks", qos: .userInteractive)

    var clicksPerSecond: Double {
        let intervalSeconds = max(intervalMillis, 1) / 1000
        return Double(clicksPerBurst) / intervalSeconds
    }

    func refreshAccessibilityStatus() {
        hasAccessibility = AXIsProcessTrusted()
    }

    func requestAccessibilityAccess() {
        let options = [kAXTrustedCheckOptionPrompt as String: true] as CFDictionary
        hasAccessibility = AXIsProcessTrustedWithOptions(options)
    }

    func openAccessibilitySettings() {
        NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility")!)
    }

    func toggle() {
        isRunning ? stop() : start()
    }

    func start() {
        refreshAccessibilityStatus()
        guard hasAccessibility else {
            requestAccessibilityAccess()
            return
        }

        stop()
        totalClicks = 0
        isRunning = true

        let timer = DispatchSource.makeTimerSource(queue: clickQueue)
        timer.schedule(deadline: .now(), repeating: .milliseconds(Int(max(intervalMillis, 5))))
        timer.setEventHandler { [weak self] in
            self?.performBurst()
        }
        self.timer = timer
        timer.resume()
    }

    func stop() {
        timer?.cancel()
        timer = nil
        if isRunning {
            DispatchQueue.main.async {
                self.isRunning = false
            }
        }
    }

    private func performBurst() {
        let burst = DispatchQueue.main.sync { max(clicksPerBurst, 1) }
        let activeButton = DispatchQueue.main.sync { button }

        for _ in 0..<burst {
            autoreleasepool {
                performClick(activeButton)
            }

            let shouldStop = DispatchQueue.main.sync { () -> Bool in
                totalClicks += 1
                return maxClicks > 0 && totalClicks >= maxClicks
            }

            if shouldStop {
                DispatchQueue.main.async { self.stop() }
                return
            }
        }
    }

    private func performClick(_ activeButton: ClickButton) {
        guard let source = CGEventSource(stateID: .hidSystemState),
              let current = CGEvent(source: source) else {
            return
        }

        let location = current.location
        let down = CGEvent(mouseEventSource: source, mouseType: activeButton.downEvent, mouseCursorPosition: location, mouseButton: activeButton.cgButton)
        let up = CGEvent(mouseEventSource: source, mouseType: activeButton.upEvent, mouseCursorPosition: location, mouseButton: activeButton.cgButton)

        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
    }
}

final class HotKeyBridge {
    private var globalMonitor: Any?
    private var localMonitor: Any?

    func install(toggle: @escaping () -> Void) {
        let handler: (NSEvent) -> NSEvent? = { event in
            guard event.keyCode == 35,
                  event.modifierFlags.contains(.command),
                  event.modifierFlags.contains(.shift) else {
                return event
            }

            toggle()
            return nil
        }

        localMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown, handler: handler)
        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { event in
            _ = handler(event)
        }
    }

    deinit {
        if let localMonitor {
            NSEvent.removeMonitor(localMonitor)
        }
        if let globalMonitor {
            NSEvent.removeMonitor(globalMonitor)
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.applicationIconImage = PandaIconFactory.makeIcon()
        NSApp.activate(ignoringOtherApps: true)
    }
}

enum PandaIconFactory {
    static func makeIcon() -> NSImage {
        let size = NSSize(width: 512, height: 512)
        let image = NSImage(size: size)
        image.lockFocus()

        NSColor(calibratedRed: 0.88, green: 0.96, blue: 0.90, alpha: 1).setFill()
        NSBezierPath(roundedRect: NSRect(x: 32, y: 32, width: 448, height: 448), xRadius: 88, yRadius: 88).fill()

        NSColor(calibratedWhite: 0.06, alpha: 1).setFill()
        NSBezierPath(ovalIn: NSRect(x: 118, y: 310, width: 96, height: 96)).fill()
        NSBezierPath(ovalIn: NSRect(x: 298, y: 310, width: 96, height: 96)).fill()

        NSColor.white.setFill()
        NSBezierPath(ovalIn: NSRect(x: 110, y: 92, width: 292, height: 292)).fill()

        NSColor(calibratedWhite: 0.06, alpha: 1).setFill()
        NSBezierPath(ovalIn: NSRect(x: 164, y: 212, width: 72, height: 92)).fill()
        NSBezierPath(ovalIn: NSRect(x: 276, y: 212, width: 72, height: 92)).fill()
        NSBezierPath(roundedRect: NSRect(x: 231, y: 172, width: 50, height: 34), xRadius: 14, yRadius: 14).fill()

        NSColor.white.setFill()
        NSBezierPath(ovalIn: NSRect(x: 190, y: 250, width: 18, height: 18)).fill()
        NSBezierPath(ovalIn: NSRect(x: 304, y: 250, width: 18, height: 18)).fill()

        image.unlockFocus()
        return image
    }
}

@main
struct PandaClickerApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var engine = ClickerEngine()
    private let hotKeyBridge = HotKeyBridge()

    var body: some Scene {
        WindowGroup {
            ContentView(engine: engine)
                .frame(minWidth: 760, minHeight: 520)
                .onAppear {
                    hotKeyBridge.install {
                        DispatchQueue.main.async {
                            engine.toggle()
                        }
                    }
                }
        }
        .windowStyle(.hiddenTitleBar)

        MenuBarExtra(engine.isRunning ? "PandaClicker: On" : "PandaClicker: Off", systemImage: engine.isRunning ? "pawprint.fill" : "pawprint") {
            Button(engine.isRunning ? "Stop Clicking" : "Start Clicking") {
                engine.toggle()
            }

            Button("Open Accessibility Settings") {
                engine.openAccessibilitySettings()
            }

            Divider()

            Button("Quit PandaClicker") {
                NSApp.terminate(nil)
            }
        }
    }
}

struct ContentView: View {
    @ObservedObject var engine: ClickerEngine
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.96, green: 0.98, blue: 0.96),
                    Color(red: 0.88, green: 0.95, blue: 0.91),
                    Color(red: 0.95, green: 0.91, blue: 0.88)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                HeaderView(engine: engine)
                Divider().opacity(0.35)

                HStack(spacing: 22) {
                    ControlPanel(engine: engine)
                    StatusPanel(engine: engine)
                }
                .padding(24)
            }
        }
        .preferredColorScheme(colorScheme)
    }
}

struct HeaderView: View {
    @ObservedObject var engine: ClickerEngine

    var body: some View {
        HStack(spacing: 18) {
            ZStack {
                Circle()
                    .fill(Color.white)
                    .frame(width: 72, height: 72)
                    .shadow(color: .black.opacity(0.12), radius: 18, x: 0, y: 10)

                PandaMark()
                    .frame(width: 58, height: 58)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("PandaClicker")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundStyle(Color(red: 0.10, green: 0.13, blue: 0.12))

                Text("Free macOS autoclicker by Owldev")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button {
                engine.toggle()
            } label: {
                Label(engine.isRunning ? "Stop" : "Start", systemImage: engine.isRunning ? "stop.fill" : "play.fill")
                    .frame(width: 118)
            }
            .buttonStyle(PrimaryButtonStyle(isActive: engine.isRunning))
            .keyboardShortcut(.space, modifiers: [])
        }
        .padding(.horizontal, 28)
        .padding(.vertical, 24)
    }
}

struct ControlPanel: View {
    @ObservedObject var engine: ClickerEngine

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Controls")
                .font(.system(size: 18, weight: .semibold))

            VStack(alignment: .leading, spacing: 10) {
                Label("Click interval", systemImage: "timer")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)

                HStack {
                    Slider(value: $engine.intervalMillis, in: 5...2000, step: 5)
                    TextField("ms", value: $engine.intervalMillis, format: .number)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 82)
                    Text("ms")
                        .foregroundStyle(.secondary)
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                Label("Clicks per burst", systemImage: "bolt.fill")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)

                Stepper(value: $engine.clicksPerBurst, in: 1...50) {
                    Text("\(engine.clicksPerBurst) click\(engine.clicksPerBurst == 1 ? "" : "s")")
                        .font(.system(size: 16, weight: .medium))
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                Label("Mouse button", systemImage: "cursorarrow.click")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)

                Picker("Mouse button", selection: $engine.button) {
                    ForEach(ClickButton.allCases) { button in
                        Text(button.rawValue).tag(button)
                    }
                }
                .pickerStyle(.segmented)
            }

            VStack(alignment: .leading, spacing: 10) {
                Label("Safety stop", systemImage: "shield.checkered")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)

                HStack {
                    TextField("0 for unlimited", value: $engine.maxClicks, format: .number)
                        .textFieldStyle(.roundedBorder)
                    Text("max clicks")
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            Text("Quick toggle: Command + Shift + P")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.secondary)
        }
        .padding(22)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(.white.opacity(0.72), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(.white.opacity(0.85), lineWidth: 1))
    }
}

struct StatusPanel: View {
    @ObservedObject var engine: ClickerEngine

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("Status")
                    .font(.system(size: 18, weight: .semibold))
                Spacer()
                StatusPill(isRunning: engine.isRunning)
            }

            VStack(spacing: 14) {
                MetricRow(title: "Mode", value: engine.isRunning ? "Running" : "Ready", symbol: engine.isRunning ? "dot.radiowaves.left.and.right" : "checkmark.circle.fill")
                MetricRow(title: "Speed", value: "\(engine.clicksPerSecond.formatted(.number.precision(.fractionLength(1)))) cps", symbol: "speedometer")
                MetricRow(title: "Total clicks", value: "\(engine.totalClicks)", symbol: "number")
                MetricRow(title: "Button", value: engine.button.rawValue, symbol: "cursorarrow.click.2")
            }

            if !engine.hasAccessibility {
                VStack(alignment: .leading, spacing: 12) {
                    Label("Accessibility permission needed", systemImage: "lock.shield.fill")
                        .font(.system(size: 14, weight: .semibold))

                    Text("macOS requires Accessibility access before any app can send mouse clicks.")
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)

                    Button {
                        engine.openAccessibilitySettings()
                    } label: {
                        Label("Open Accessibility Settings", systemImage: "gearshape.fill")
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(16)
                .background(Color(red: 1.0, green: 0.95, blue: 0.80), in: RoundedRectangle(cornerRadius: 8))
            } else {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Ready for macOS", systemImage: "checkmark.seal.fill")
                        .font(.system(size: 14, weight: .semibold))
                    Text("Move your cursor where you want clicks, then start.")
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                }
                .padding(16)
                .background(Color(red: 0.86, green: 0.95, blue: 0.88), in: RoundedRectangle(cornerRadius: 8))
            }

            Spacer()

            HStack {
                Text("100% free")
                Spacer()
                Text("Credits: Owldev")
            }
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(.secondary)
        }
        .padding(22)
        .frame(width: 310, maxHeight: .infinity, alignment: .topLeading)
        .background(.white.opacity(0.72), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(.white.opacity(0.85), lineWidth: 1))
    }
}

struct MetricRow: View {
    let title: String
    let value: String
    let symbol: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Color(red: 0.16, green: 0.42, blue: 0.31))
                .frame(width: 28, height: 28)
                .background(Color(red: 0.89, green: 0.96, blue: 0.91), in: RoundedRectangle(cornerRadius: 7))

            Text(title)
                .foregroundStyle(.secondary)

            Spacer()

            Text(value)
                .fontWeight(.semibold)
                .foregroundStyle(Color(red: 0.10, green: 0.13, blue: 0.12))
        }
        .font(.system(size: 14))
    }
}

struct StatusPill: View {
    let isRunning: Bool

    var body: some View {
        HStack(spacing: 7) {
            Circle()
                .fill(isRunning ? Color.green : Color.gray)
                .frame(width: 8, height: 8)
            Text(isRunning ? "ON" : "OFF")
                .font(.system(size: 12, weight: .bold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(isRunning ? Color.green.opacity(0.16) : Color.gray.opacity(0.14), in: Capsule())
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    let isActive: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(.white)
            .padding(.vertical, 12)
            .background(
                LinearGradient(
                    colors: isActive
                        ? [Color(red: 0.80, green: 0.18, blue: 0.18), Color(red: 0.55, green: 0.10, blue: 0.10)]
                        : [Color(red: 0.10, green: 0.42, blue: 0.30), Color(red: 0.05, green: 0.25, blue: 0.19)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 8, style: .continuous)
            )
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .shadow(color: .black.opacity(0.16), radius: 14, x: 0, y: 8)
    }
}

struct PandaMark: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color(red: 0.08, green: 0.10, blue: 0.10))
                .frame(width: 18, height: 18)
                .offset(x: -20, y: -20)

            Circle()
                .fill(Color(red: 0.08, green: 0.10, blue: 0.10))
                .frame(width: 18, height: 18)
                .offset(x: 20, y: -20)

            Circle()
                .fill(Color.white)
                .frame(width: 48, height: 48)

            Ellipse()
                .fill(Color(red: 0.08, green: 0.10, blue: 0.10))
                .frame(width: 14, height: 18)
                .rotationEffect(.degrees(-24))
                .offset(x: -11, y: -3)

            Ellipse()
                .fill(Color(red: 0.08, green: 0.10, blue: 0.10))
                .frame(width: 14, height: 18)
                .rotationEffect(.degrees(24))
                .offset(x: 11, y: -3)

            Circle()
                .fill(Color.white)
                .frame(width: 4, height: 4)
                .offset(x: -9, y: -5)

            Circle()
                .fill(Color.white)
                .frame(width: 4, height: 4)
                .offset(x: 9, y: -5)

            RoundedRectangle(cornerRadius: 4)
                .fill(Color(red: 0.08, green: 0.10, blue: 0.10))
                .frame(width: 10, height: 7)
                .offset(y: 8)
        }
    }
}
