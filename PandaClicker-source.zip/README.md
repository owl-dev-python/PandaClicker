# PandaClicker

A clean, free macOS-only autoclicker with a soft panda theme and credits to Owldev.

## What It Does

- Starts and stops clicking from a polished native Mac window.
- Supports left and right click.
- Lets you choose interval, clicks per burst, and a maximum-click safety stop.
- Includes a menu-bar status indicator.
- Uses `Command + Shift + P` as a quick toggle while the app is open.
- Shows Owldev credit in the app.

## Mac Permissions

macOS blocks click automation until you allow Accessibility access.

1. Open PandaClicker.
2. Click `Open Accessibility Settings`.
3. Enable PandaClicker in `System Settings > Privacy & Security > Accessibility`.
4. Restart the app if macOS asks you to.

## Build The Mac App

This must be built on macOS, not Windows:

```bash
cd PandaClicker
chmod +x scripts/build-mac.sh
./scripts/build-mac.sh
open build/PandaClicker.app
```

The finished app will be here:

```text
build/PandaClicker.app
```

## Build From Windows Without Owning A Mac

Windows cannot directly build a ready-to-open macOS `.app`. Use the included free GitHub Actions workflow to build it on a hosted Mac:

1. Create a GitHub repository for this `PandaClicker` folder.
2. Push the project to GitHub.
3. Open the repository on GitHub.
4. Go to `Actions > Build macOS App > Run workflow`.
5. Download the `PandaClicker-macOS` artifact.
6. Unzip `PandaClicker-macOS.zip` and send `PandaClicker.app` to your girlfriend.

Public GitHub repositories can use GitHub-hosted macOS runners for free. Private repositories may use account minutes.

## Run During Development

```bash
swift run
```

## Notes

`.exe` files are for Windows. On macOS, the normal app format is `.app`, so this project builds `PandaClicker.app`.

PandaClicker is 100% free. Credit: Owldev.
