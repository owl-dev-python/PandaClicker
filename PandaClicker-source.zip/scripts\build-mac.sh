#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP_NAME="PandaClicker"
BUILD_DIR="$ROOT_DIR/build"
APP_DIR="$BUILD_DIR/$APP_NAME.app"
MACOS_DIR="$APP_DIR/Contents/MacOS"
RESOURCES_DIR="$APP_DIR/Contents/Resources"
ARM_BINARY="$BUILD_DIR/$APP_NAME-arm64"
INTEL_BINARY="$BUILD_DIR/$APP_NAME-x86_64"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This project builds a macOS .app and must be built on a Mac."
  exit 1
fi

rm -rf "$BUILD_DIR"
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

compile_for_arch() {
  local arch="$1"
  local output="$2"

  swiftc \
    -O \
    -parse-as-library \
    -target "$arch-apple-macos13" \
    -framework SwiftUI \
    -framework AppKit \
    -framework ApplicationServices \
    "$ROOT_DIR"/Sources/PandaClicker/*.swift \
    -o "$output"
}

compile_for_arch arm64 "$ARM_BINARY"
compile_for_arch x86_64 "$INTEL_BINARY"
lipo -create "$ARM_BINARY" "$INTEL_BINARY" -output "$MACOS_DIR/$APP_NAME"

cp "$ROOT_DIR/Resources/Info.plist" "$APP_DIR/Contents/Info.plist"

echo "Built: $APP_DIR"
echo "Open it with: open \"$APP_DIR\""
